

import 'package:cimso_membership_v1/Theme/Dark_Mode.dart';
import 'package:cimso_membership_v1/Theme/Light_Mode.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ThemeProvider with ChangeNotifier{
  ThemeData _themeData = lightMode;
   ThemeData get themeData => _themeData;

   bool get isDark_Mode => _themeData == darkMode;

   set themeData(ThemeData themeData){
     _themeData= themeData;
     notifyListeners();
   }
   void  toggleTheme(){
     if (_themeData == lightMode){
      themeData = darkMode;
     } else{
       themeData = lightMode;
     }
   }
}