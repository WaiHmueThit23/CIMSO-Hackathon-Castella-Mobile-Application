import 'package:flutter/material.dart';
import 'HotelReservationPage.dart';
import 'TypeReservationPage.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String selectedCategory = "All Hotel";
  TextEditingController locationController = TextEditingController();

  List<Map<String, dynamic>> allHotels = [
    {
      "name": "Castella Hotel",
      "location": "Bangkok, Thailand",
      "price": "฿3599/night",
      "rating": 4.8,
      "reviews": "6,283 reviews",
      "image": "assets/images/hotellobby.jpg", // Hotel image (still .jpg)
    },
    {
      "name": "Castella Royal Hotel",
      "location": "Phuket, Thailand",
      "price": "฿4599/night",
      "rating": 4.8,
      "reviews": "6,129 reviews",
      "image": "assets/images/hotellobby1.jpg", // Hotel image (still .jpg)
    },
    {
      "name": "Castella Delight Hotel",
      "location": "ChiangMai, Thailand",
      "price": "฿4099/night",
      "rating": 4.8,
      "reviews": "5,182 reviews",
      "image": "assets/images/lobby.jpg", // Hotel image (still .jpg)
    },
    {
      "name": "Castella Hotel",
      "location": "Hua Hin, Thailand",
      "price": "฿3599/night",
      "rating": 4.8,
      "reviews": "4,303 reviews",
      "image": "assets/images/lobby1.jpg", // Hotel image (still .jpg)
    },
  ];

  List<Map<String, dynamic>> get filteredHotels {
    List<Map<String, dynamic>> hotels = List.from(allHotels);

    if (selectedCategory == "Recommended") {
      hotels = hotels.where((hotel) => hotel["name"].contains("Delight")).toList();
    } else if (selectedCategory == "Trending") {
      hotels = hotels.where((hotel) => hotel["name"].contains("Royal")).toList();
    }

    if (locationController.text.isNotEmpty) {
      hotels = hotels.where((hotel) =>
          hotel["location"].toLowerCase().contains(locationController.text.toLowerCase())).toList();
    }

    return hotels;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: TextField(
          decoration: InputDecoration(
            hintText: "Search hotels",
            prefixIcon: Icon(Icons.search, color: Colors.grey),
            filled: true,
            fillColor: Colors.grey[200],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
              borderSide: BorderSide.none,
            ),
          ),
          onChanged: (value) {
            setState(() {});
          },
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  "assets/images/bkk.gif", // Replace map with your gif
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: locationController,
              decoration: InputDecoration(
                hintText: "Enter location",
                prefixIcon: Icon(Icons.location_on, color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onChanged: (value) {
                setState(() {});
              },
            ),
            SizedBox(height: 16),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  filterButton("All Hotels"),
                  filterButton("Recommended"),
                  filterButton("Trending"),
                ],
              ),
            ),
            SizedBox(height: 16),
            Text(
              "$selectedCategory (${filteredHotels.length})",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.8,
                ),
                itemCount: filteredHotels.length,
                itemBuilder: (context, index) {
                  return hotelCard(filteredHotels[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget hotelCard(Map<String, dynamic> hotel) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => HotelReservationPage(),
          ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 2,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  hotel["image"],
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                hotel["name"],
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget filterButton(String text) {
    bool isSelected = text == selectedCategory;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 4.0),
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedCategory = text;
          });
        },
        child: Chip(
          label: Text(text),
          backgroundColor: isSelected ? Colors.orange : Colors.grey[200],
          labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.black),
        ),
      ),
    );
  }
}
