import 'package:flutter/material.dart';
import 'Homepage.dart';

class HotelReservationPageHistory extends StatefulWidget {
  final Map<String, dynamic> userData;

  // Constructor to initialize user data
  HotelReservationPageHistory({required this.userData});

  @override
  _HotelReservationPageHistoryState createState() =>
      _HotelReservationPageHistoryState();
}

class _HotelReservationPageHistoryState
    extends State<HotelReservationPageHistory> {
  int _selectedTabIndex = 0;

  List<Map<String, String>> currentBookings = [
    {"hotel": "Castella Royal", "location": "Phuket, Thailand", "date": "5th March 2025", "time": "3:00 PM"},
  ];

  List<Map<String, String>> completedBookings = [
    {"hotel": "Castella Hotel", "location": "Bangkok, Thailand", "date": "20th Feb 2025", "time": "2:00 PM"},
    {"hotel": "Castella Delight", "location": "Chiang Mai, Thailand", "date": "18th Feb 2025", "time": "5:00 PM"},
  ];

  List<Map<String, String>> canceledBookings = [
    {"hotel": "Castella Hotel", "location": "Bangkok, Thailand", "date": "4th March 2025", "time": "10:00 AM"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Booking History"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10.0),
            child: ToggleButtons(
              isSelected: [
                _selectedTabIndex == 0,
                _selectedTabIndex == 1,
                _selectedTabIndex == 2
              ],
              onPressed: (index) {
                setState(() {
                  _selectedTabIndex = index;
                });
              },
              borderRadius: BorderRadius.circular(10),
              selectedColor: Colors.white,
              fillColor: Color(0xFFA86B32),
              color: Colors.black,
              children: [
                Padding(padding: EdgeInsets.all(10), child: Text("Current")),
                Padding(padding: EdgeInsets.all(10), child: Text("Completed")),
                Padding(padding: EdgeInsets.all(10), child: Text("Canceled")),
              ],
            ),
          ),
          Expanded(child: _getTabContent()),
        ],
      ),
    );
  }

  Widget _getTabContent() {
    if (_selectedTabIndex == 0) return _buildBookingList(currentBookings, isCurrent: true);
    if (_selectedTabIndex == 1) return _buildBookingList(completedBookings);
    return _buildBookingList(canceledBookings);
  }

  Widget _buildBookingList(List<Map<String, String>> bookings, {bool isCurrent = false}) {
    return ListView.builder(
      itemCount: bookings.length,
      itemBuilder: (context, index) {
        return _buildBookingCard(bookings[index], isCurrent);
      },
    );
  }

  Widget _buildBookingCard(Map<String, String> booking, bool isCurrent) {
    return Card(
      margin: EdgeInsets.all(12),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Pick up", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
            Row(children: [Icon(Icons.place, color: Colors.red), SizedBox(width: 5), Text(booking["location"]!)]),
            Row(children: [Icon(Icons.calendar_today, color: Color(0xFFA86B32)), SizedBox(width: 5), Text(booking["date"]!)]),
            Row(children: [Icon(Icons.access_time, color: Colors.blue), SizedBox(width: 5), Text(booking["time"]!)]),
            SizedBox(height: 10),
            Text("Hotel: ${booking["hotel"]}", style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(onPressed: () {}, child: Text("Export")),
                if (isCurrent)
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        currentBookings.remove(booking);
                        canceledBookings.add(booking);
                        _selectedTabIndex = 2;
                      });
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Color(0xFFA86B32)),
                    child: Text("Cancel", style: TextStyle(color: Colors.black)),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

