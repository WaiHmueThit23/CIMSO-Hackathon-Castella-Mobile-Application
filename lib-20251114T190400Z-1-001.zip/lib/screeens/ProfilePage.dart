import 'package:cimso_membership_v1/screeens/SignoutPage.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'Account_setting.dart';
import 'EditPage.dart';
import 'MemberCardPage.dart';
import 'PaymentPage.dart';
import 'TypeReservationPage.dart';
import 'intropage.dart';

class ProfilePage extends StatefulWidget {
  final Map<String, dynamic> userData; // User details
  ProfilePage({required this.userData});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File? _image;

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20),

          // Back Button
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              SizedBox(width: 5),
              Text(
                "Profile",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ],
          ),

          SizedBox(height: 50),
          Center(
            child: Column(
              children: [
                GestureDetector(
                  onTap: _pickImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.grey,
                    backgroundImage: _image != null ? FileImage(_image!) : null,
                    child: _image == null ? Icon(Icons.person, size: 70, color: Colors.white) : null,
                  ),
                ),
                SizedBox(height: 5),
                TextButton(
                  onPressed: _pickImage,
                  child: Text("Edit Photo", style: TextStyle(color: Color(0xFFA86B32))),
                ),
              ],
            ),
          ),
          SizedBox(height: 10),

          Text("${widget.userData['name']}", style: TextStyle(fontSize: 22)),
          Text("Membership ID: ${widget.userData['membershipID']}", style: TextStyle(fontSize: 18)),

          SizedBox(height: 20),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(20),
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PaymentPage()),
                    );
                  },
                  child: Text("Go to Payment"),
                ),
                SizedBox(height: 10),

                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => TypeReservationPage()),
                    );
                  },
                  child: Text("Type of Reservation"),
                ),
                SizedBox(height: 10),

                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MemberCardPage(userId: '',)),
                    );
                  },
                  child: Text("Member Card"),
                ),
                SizedBox(height: 10),

                ElevatedButton(
                  onPressed: () async {
                    final updatedUserData = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EditPage(userData: widget.userData),
                      ),
                    );

                    if (updatedUserData != null) {
                      setState(() {
                        widget.userData.addAll(updatedUserData);
                      });
                    }
                  },
                  child: Text("Edit Profile"),
                ),

                SizedBox(height: 10),

                // ElevatedButton(
                //onPressed: () {
                // Navigator.push(
                //  context,
                //  MaterialPageRoute(builder: (context) => EditPage(userData: {},)), // Fixed
                // );
                //  },
                // child: Text("Account Settings"),
                // ),
                SizedBox(height: 10),

                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SecurityPage()),
                    );
                  },
                  child: Text("Security Settings"),
                ),
                SizedBox(height: 10),

                ElevatedButton(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => SignOutPage()),
                          (route) => false,
                    );
                  },
                  child: Text("Logout", style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
