import 'package:cimso_membership_v1/screeens/TypeReservationPage.dart';
import 'package:flutter/material.dart';
import 'HomePage.dart'; // Assuming HomePage is in the same directory

class TransactionPage extends StatefulWidget {
  @override
  _TransactionPageState createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  List<Map<String, dynamic>> transactions = [
    {"amount": 3999.00, "code": "3d4456Vb12a", "receiver": "Receiver", "date": "23/2/2025"},
    {"amount": 1599.00, "code": "3x7890Yu34b", "receiver": "John Doe", "date": "22/2/2025"},
    {"amount": 1399.00, "code": "4y5678Ab56c", "receiver": "Jane Doe", "date": "21/2/2025"},
    {"amount": 1599.00, "code": "5z3456Cd78d", "receiver": "Alice Smith", "date": "20/2/2025"},
  ];

  bool isExpanded = false; // Track if all transactions are expanded

  void _toggleTransactionDetails() {
    setState(() {
      isExpanded = !isExpanded;
    });
  }

  void _goToHomePage() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => TypeReservationPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('History')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Dropdown Button for Expanding All Transactions
            GestureDetector(
              onTap: _toggleTransactionDetails,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFA86B32),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("View Transactions", style: const TextStyle(fontSize: 16, color: Colors.white)),
                    Icon(isExpanded ? Icons.arrow_drop_up : Icons.arrow_drop_down, color: Colors.white),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Expanded Transactions List
            if (isExpanded)
              Expanded(
                child: ListView.builder(
                  itemCount: transactions.length,
                  itemBuilder: (context, index) {
                    var transaction = transactions[index];
                    return _buildTransactionItem(
                      transaction["amount"],
                      transaction["code"],
                      transaction["receiver"],
                      transaction["date"],
                    );
                  },
                ),
              ),

            const SizedBox(height: 20),

            // Back Home Button
            _buildStyledButton('Back Home', _goToHomePage),
          ],
        ),
      ),
    );
  }

  Widget _buildStyledButton(String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity, // Full width
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFA86B32),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Text(
            text,
            style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }

  Widget _buildTransactionItem(double amount, [String? code, String? receiver, String? date]) {
    return Card(
      color: const Color(0xFFA86B32),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Amount: $amount B', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            if (code != null && receiver != null && date != null) ...[
              const SizedBox(height: 5),
              Text('Transaction Code: $code', style: const TextStyle(color: Colors.grey)),
              Text('Transfer to: $receiver', style: const TextStyle(color: Colors.grey)),
              Text('Transaction Date: $date', style: const TextStyle(color: Colors.grey)),
            ],
          ],
        ),
      ),
    );
  }
}
