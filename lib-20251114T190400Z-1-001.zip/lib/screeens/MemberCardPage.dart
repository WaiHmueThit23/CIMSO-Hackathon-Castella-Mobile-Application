import 'package:flutter/material.dart';
import 'dart:math';
import 'SubscriptionPage.dart';

class MemberCardPage extends StatelessWidget {
  final String userId;

  MemberCardPage({required this.userId});

  // Function to generate a random membership ID
  String generateMembershipID() {
    final random = Random();
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return List.generate(10, (index) => characters[random.nextInt(characters.length)]).join();
  }

  // Function to generate a random expiry date (1 year from today)
  String generateExpireDate() {
    final currentDate = DateTime.now();
    final expiryDate = currentDate.add(Duration(days: 365)); // 1 year expiry
    return '${expiryDate.year}-${expiryDate.month.toString().padLeft(2, '0')}-${expiryDate.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    // Simulated user data
    String membershipID = generateMembershipID();
    String expireDate = generateExpireDate();
    int points = 580; // Default points
    String rank = 'Bronze'; // Default rank

    return Scaffold(
      appBar: AppBar(
        title: Text("Member Card"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 20),
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.brown.shade300, Colors.amber.shade300],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Castella Member Card", style: TextStyle(fontSize: 18, color: Colors.white)),
                SizedBox(height: 10),
                Text("Membership ID: $membershipID", style: TextStyle(fontSize: 14, color: Colors.white70)),
                Text("Expire Date: $expireDate", style: TextStyle(fontSize: 14, color: Colors.white70)),
                SizedBox(height: 10),
                Text("Current Points", style: TextStyle(fontSize: 14, color: Colors.white70)),
                Text(points.toString(), style: TextStyle(fontSize: 28, color: Colors.white)),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(rank, style: TextStyle(fontSize: 18, color: Colors.white)),
                    Icon(Icons.verified, color: Colors.white),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                Text(
                  "Upgrade Your Member Card to experience our best promotions",
                  style: TextStyle(fontSize: 14, color: Colors.black54),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SubscriptionPage()),
                    );
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.amber),
                  child: Text("Upgrade"),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TextButton(
                  onPressed: () {
                    // You can add a real Redeem Page later
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RedeemPage(userData: {})),
                    );
                  },
                  child: Text("Redeem", style: TextStyle(fontSize: 16, color: Colors.black)),
                ),
                TextButton(
                  onPressed: () {
                    // You can add a real History Page later
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => HistoryPage()),
                    );
                  },
                  child: Text("History", style: TextStyle(fontSize: 16, color: Colors.black)),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: ListView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              children: [
                redeemItem("Deluxe 50% off", "44500"),
                redeemItem("King Premium 50% off", "9990"),
                redeemItem("Classic 50% off", "8240"),
                redeemItem("Set Menu 50% off", "440"),
                redeemItem("Buffets 50% off", "740"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget redeemItem(String title, String points) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [BoxShadow(color: Colors.grey.shade300, blurRadius: 5)],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: TextStyle(fontSize: 16)),
            Row(
              children: [
                Icon(Icons.monetization_on, color: Colors.amber),
                SizedBox(width: 5),
                Text(points, style: TextStyle(fontSize: 16)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class RedeemPage extends StatelessWidget {
  final Map<String, dynamic> userData;

  RedeemPage({required this.userData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Redeem Points")),
      body: Center(child: Text("Redeem functionality coming soon!")),
    );
  }
}

class HistoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Redeem History")),
      body: ListView(
        padding: EdgeInsets.all(20),
        children: [
          historyItem("Deluxe 50% off", "44500"),
          historyItem("Set Menu 50% off", "440"),
        ],
      ),
    );
  }

  Widget historyItem(String title, String points) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [BoxShadow(color: Colors.grey.shade300, blurRadius: 5)],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: TextStyle(fontSize: 16)),
            Row(
              children: [
                Icon(Icons.monetization_on, color: Colors.amber),
                SizedBox(width: 5),
                Text(points, style: TextStyle(fontSize: 16)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
