import 'package:flutter/material.dart';
import 'ProfilePage.dart';

class HomePage extends StatelessWidget {
  final Map<String, dynamic> userData;
  HomePage({required this.userData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 50),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Accessing full name from userData map
                Text("Welcome, ${userData['name']}!", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                Icon(Icons.notifications),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(10),
              children: [
                hotelCard(context, "Luxury Suite", "Castella,ChaingMai", "\฿4599 / night"),
                hotelCard(context, "Castella Hotel", "Castella,Hua Hin", "\฿3599 / night"),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
        onTap: (index) {
          if (index == 2) {
            // Navigating to ProfilePage with the user data
            Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfilePage(userData: userData))
            );
          }
        },
      ),
    );
  }

  Widget hotelCard(BuildContext context, String name, String location, String price) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(height: 150, color: Colors.grey), // Placeholder for image
          Padding(
            padding: EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                Text(location, style: TextStyle(color: Colors.grey)),
                SizedBox(height: 5),
                Text(price, style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFA86B32))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
