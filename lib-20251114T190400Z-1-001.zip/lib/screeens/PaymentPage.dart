import 'package:flutter/material.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';
import 'TransactionPage.dart';
import 'TypeReservationPage.dart';

class PaymentPage extends StatefulWidget {
  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  String selectedMethod = "Paypal";
  bool showConfirmation = false;
  bool newCardAdded = false;

  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String cardNumber = "";
  String expiryDate = "";
  String cardHolderName = "";
  String cvvCode = "";
  bool isCvvFocused = false;

  List<Map<String, String>> paymentMethods = [
    {"name": "Paypal", "image": 'assets/images/paypal_logo.png'},
    {"name": "Google Pay", "image": 'assets/images/google.png'},
    {"name": "Apple Pay", "image": 'assets/images/apple.png'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("Payment", style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: showConfirmation
          ? ConfirmationPage(onBack: () {
        setState(() {
          showConfirmation = false;
        });
      })
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Checkout", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),

            // Credit Card UI
            CreditCardWidget(
              cardNumber: cardNumber,
              expiryDate: expiryDate,
              cardHolderName: cardHolderName,
              cvvCode: cvvCode,
              showBackView: isCvvFocused,
              onCreditCardWidgetChange: (CreditCardBrand brand) {},
              cardBgColor: Colors.blue,
              chipColor: Colors.white,
              textStyle: TextStyle(color: Colors.white),
            ),

            SizedBox(height: 20),

            // Credit Card Form
            CreditCardForm(
              cardNumber: cardNumber,
              expiryDate: expiryDate,
              cardHolderName: cardHolderName,
              cvvCode: cvvCode,
              onCreditCardModelChange: (data) {
                setState(() {
                  cardNumber = data.cardNumber;
                  expiryDate = data.expiryDate;
                  cardHolderName = data.cardHolderName;
                  cvvCode = data.cvvCode;
                  isCvvFocused = data.isCvvFocused;
                });
              },
              formKey: formKey,
            ),

            Spacer(),

            // Continue Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    showConfirmation = true;
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFA86B32),
                  padding: EdgeInsets.symmetric(vertical: 20),
                ),
                child: Text("Continue", style: TextStyle(fontSize: 22, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ConfirmationPage extends StatelessWidget {
  final VoidCallback onBack;

  ConfirmationPage({required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Payment Successful!",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),

          // History of Transaction Button
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TransactionPage()),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFFA86B32),
            ),
            child: Text("Transaction History", style: TextStyle(color: Colors.white)),
          ),

          SizedBox(height: 10),

          // Go to Homepage Button
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TypeReservationPage()),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFFA86B32),
            ),
            child: Text("Go to Homepage", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}