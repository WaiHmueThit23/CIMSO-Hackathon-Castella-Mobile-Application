import 'package:cimso_membership_v1/screeens/PaymentPage.dart';
import 'package:flutter/material.dart';


class SelectDatePage extends StatefulWidget {
  @override
  _SelectDatePageState createState() => _SelectDatePageState();
}

class _SelectDatePageState extends State<SelectDatePage> {
  DateTime? checkIn;
  DateTime? checkOut;
  int guests = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Select Date"), backgroundColor: Color(0xFFA86B32)),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 📅 Calendar Moved to the Top
            Center(
              child: Text("Select Your Dates", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            SizedBox(height: 10),
            CalendarDatePicker(
              firstDate: DateTime(2025, 4, 1),
              lastDate: DateTime(2025, 4, 30),
              initialDate: DateTime(2025, 4, 1),
              onDateChanged: (date) {
                setState(() {
                  if (checkIn == null || (checkIn != null && checkOut != null)) {
                    checkIn = date;
                    checkOut = null;
                  } else {
                    checkOut = date;
                  }
                });
              },
            ),
            SizedBox(height: 20),

            // 🏨 Check-in & Check-out Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Check-in", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Text(checkIn != null ? "${checkIn!.toLocal()}".split(' ')[0] : "Select a date",
                        style: TextStyle(fontSize: 16)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Check-out", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Text(checkOut != null ? "${checkOut!.toLocal()}".split(' ')[0] : "Select a date",
                        style: TextStyle(fontSize: 16)),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20),

            // 👥 Guest Selection
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Guests: $guests", style: TextStyle(fontSize: 16)),
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.remove),
                      onPressed: () {
                        setState(() {
                          if (guests > 1) guests--;
                        });
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.add),
                      onPressed: () {
                        setState(() {
                          guests++;
                        });
                      },
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20),


            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PaymentPage()),
                  );

                },
                style: ElevatedButton.styleFrom(backgroundColor: Color(0xFFA86B32)),
                child: Text("Continue", style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}