import 'package:flutter/material.dart';
import 'dart:math';
import 'ProfilePage.dart'; // Import the ProfilePage

class FillProfilePage extends StatefulWidget {
  @override
  _FillProfilePageState createState() => _FillProfilePageState();
}

class _FillProfilePageState extends State<FillProfilePage> {
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  String? selectedGender;
  String clientID = '';
  String membershipID = '';

  // Function to generate random ID
  String generateRandomID(int length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    Random random = Random();
    return List.generate(length, (index) => chars[random.nextInt(chars.length)]).join();
  }

  @override
  void initState() {
    super.initState();
    // Generate random Client ID and Membership ID when the page is initialized
    clientID = generateRandomID(8); // 8 characters for Client ID
    membershipID = generateRandomID(10); // 10 characters for Membership ID
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20),

          // Back Button
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              SizedBox(width: 5),
              Text(
                "Fill Your Profile",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ],
          ),

          SizedBox(height: 30),

          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                buildTextField("Full Name", fullNameController),
                buildInfoField("Membership ID", membershipID), // Display Membership ID
                buildDatePickerField("Date of Birth", dobController), // Now uses a calendar picker
                buildInfoField("Client ID", clientID), // Display Client ID
                buildTextField("Email", emailController, icon: Icons.email),
                buildGenderDropdown(),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    // Collecting the data into a map
                    Map<String, dynamic> userData = {
                      'name': fullNameController.text, // Change 'fullName' to 'name'
                      'clientID': clientID,
                      'dob': dobController.text,
                      'email': emailController.text,
                      'membershipID': membershipID,
                      'gender': selectedGender,
                    };

                    // Passing user data to ProfilePage
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ProfilePage(userData: userData)),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFA86B32),
                    padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  ),
                  child: const Text("Continue"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller, {IconData? icon}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: icon != null ? Icon(icon) : null,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget buildInfoField(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: TextEditingController()..text = value,
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget buildDatePickerField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          suffixIcon: Icon(Icons.calendar_today),
        ),
        onTap: () async {
          DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(1900),
            lastDate: DateTime.now(),
          );
          if (pickedDate != null) {
            setState(() {
              controller.text = "${pickedDate.year}-${pickedDate.month}-${pickedDate.day}";
            });
          }
        },
      ),
    );
  }

  Widget buildGenderDropdown() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: DropdownButtonFormField<String>(
        value: selectedGender,
        onChanged: (newValue) {
          setState(() {
            selectedGender = newValue;
          });
        },
        items: ["Male", "Female", "Other"].map((gender) {
          return DropdownMenuItem(
            value: gender,
            child: Text(gender),
          );
        }).toList(),
        decoration: InputDecoration(
          labelText: "Gender",
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }
}
