import 'package:flutter/material.dart';

class EditPage extends StatefulWidget {
  final Map<String, dynamic> userData;
  EditPage({required this.userData});

  @override
  _EditPageState createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  // TextEditingControllers to fill in the profile info
  late TextEditingController _fullNameController;
  late TextEditingController _membershipIDController;
  late TextEditingController _dobController;
  late TextEditingController _emailController;
  late TextEditingController _clientIDController;
  late TextEditingController _genderController;

  @override
  void initState() {
    super.initState();

    // Initialize the controllers with the passed data
    _fullNameController = TextEditingController(text: widget.userData['name']);
    _membershipIDController = TextEditingController(text: widget.userData['membershipID']);
    _dobController = TextEditingController(text: widget.userData['dob']);
    _emailController = TextEditingController(text: widget.userData['email']);
    _clientIDController = TextEditingController(text: widget.userData['clientID']);
    _genderController = TextEditingController(text: widget.userData['gender']);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            title: Text('Edit Profile'),
            floating: true,
            snap: true,
            expandedHeight: 100,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(color: Colors.blue),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextField(
                      controller: _fullNameController,
                      decoration: InputDecoration(labelText: 'Full Name'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      controller: _membershipIDController,
                      decoration: InputDecoration(labelText: 'Membership ID'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      controller: _dobController,
                      decoration: InputDecoration(labelText: 'Date of Birth'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      controller: _emailController,
                      decoration: InputDecoration(labelText: 'Email'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      controller: _clientIDController,
                      decoration: InputDecoration(labelText: 'Client ID'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      controller: _genderController,
                      decoration: InputDecoration(labelText: 'Gender'),
                    ),
                    SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: () {
                        // Create a map with updated values
                        Map<String, String> updatedData = {
                          'name': _fullNameController.text,
                          'membershipID': _membershipIDController.text,
                          'dob': _dobController.text,
                          'email': _emailController.text,
                          'clientID': _clientIDController.text,
                          'gender': _genderController.text,
                        };

                        // Print updated info for debugging
                        print("Updated Profile Info:");
                        print("Full Name: ${_fullNameController.text}");
                        print("Membership ID: ${_membershipIDController.text}");
                        print("Date of Birth: ${_dobController.text}");
                        print("Email: ${_emailController.text}");
                        print("Client ID: ${_clientIDController.text}");
                        print("Gender: ${_genderController.text}");

                        // Return the updated data to ProfilePage
                        Navigator.pop(context, updatedData);
                      },
                      child: Text('Update'),
                    ),

                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
