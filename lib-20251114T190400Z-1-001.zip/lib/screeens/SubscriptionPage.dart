import 'package:flutter/material.dart';

class SubscriptionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Subscription Method"),
        backgroundColor: Color(0xFFE8723C),
      ),
      body: Container(
        color: Color(0xFFA86B32),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                SubscriptionCard(
                  tier: "Bronze",
                  description: [
                    "Sign up to get membership",
                    "Book 1 time to reach Bronze",
                    "Redeem points for more privileges",
                    "Reach next 3000 points to get Silver card",
                  ],
                  color: Color(0xFFEFB066),
                  icon: Icons.shield,
                ),
                SubscriptionCard(
                  tier: "Silver",
                  description: [
                    "Book 3 times to reach Silver",
                    "Spend over 7000 to get this level",
                    "Redeem points for more privileges",
                    "Reach next 6000 points to get Platinum card",
                  ],
                  color: Color(0xFFECECEC),
                  icon: Icons.star,
                ),
                SubscriptionCard(
                  tier: "Platinum",
                  description: [
                    "Spend 20000 baht",
                    "Book 6 times to reach Platinum",
                    "Redeem points for more privileges",
                    "Maximize the status for privileges",
                  ],
                  color: Color(0xFFB1D8D8),
                  icon: Icons.diamond,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SubscriptionCard extends StatelessWidget {
  final String tier;
  final List<String> description;
  final Color color;
  final IconData icon;

  SubscriptionCard({
    required this.tier,
    required this.description,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    Color boxColor = color.withOpacity(0.6);
    Color iconColor = color.withOpacity(0.8);

    return Container(
      margin: EdgeInsets.only(bottom: 16),
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: boxColor,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(icon, size: 50, color: iconColor),
              SizedBox(height: 10),
              Text(
                tier,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              SizedBox(height: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: description.map((text) => Padding(
                  padding: const EdgeInsets.only(bottom: 4.0),
                  child: Text(
                    "• $text",
                    style: TextStyle(fontSize: 14, color: Colors.white),
                  ),
                )).toList(),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
                onPressed: () {},
                child: Text("Upgrade", style: TextStyle(color: Colors.black)),
              ),
              TextButton(
                onPressed: () {
                  // Navigate to the SubscriptionDetailPage on View Detail button press
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SubscriptionDetailPage(tier: tier, description: description),
                    ),
                  );
                },
                child: Text("View Detail", style: TextStyle(color: Colors.black)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class SubscriptionDetailPage extends StatelessWidget {
  final String tier;
  final List<String> description;

  SubscriptionDetailPage({
    required this.tier,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('$tier Subscription Details'),
        backgroundColor: Color(0xFFE8723C),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildMemberCard(
                color: _getCardColor(tier),
                level: tier,
                points: _getPoints(tier),
                benefits: description,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getCardColor(String tier) {
    if (tier == "Bronze") {
      return Colors.brown.shade300;
    } else if (tier == "Silver") {
      return Colors.grey.shade500;
    } else {
      return Colors.blueGrey.shade300;
    }
  }

  String _getPoints(String tier) {
    if (tier == "Bronze") {
      return '3000';
    } else if (tier == "Silver") {
      return '6000';
    } else {
      return '10000';
    }
  }

  Widget _buildMemberCard({
    required Color color,
    required String level,
    required String points,
    required List<String> benefits,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12),
          ),
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Royal Card',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  Icon(Icons.hexagon, color: Colors.white, size: 40),
                ],
              ),
              SizedBox(height: 8),
              Text(
                level,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Total Points: $points',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
              Text(
                '1 point = 2.5 baht',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Castella Royal Reward',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 8),
        Text(
          'You Have Already Achieved This Level.',
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
        SizedBox(height: 16),
        Text(
          'Redemption Record',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 8),
        Column(
          children: benefits.map((benefit) => _buildListItem(Icons.star, benefit)).toList(),
        ),
      ],
    );
  }

  Widget _buildListItem(IconData icon, String text) {
    return ListTile(
      leading: Icon(icon, color: Colors.brown),
      title: Text(text, style: TextStyle(fontSize: 16)),
    );
  }
}
