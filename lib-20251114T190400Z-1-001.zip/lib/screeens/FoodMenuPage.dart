import 'package:flutter/material.dart';

import 'RestaurantReservationPage.dart';

class FoodMenuPage extends StatefulWidget {
  @override
  _FoodMenuPageState createState() => _FoodMenuPageState();
}

class  _FoodMenuPageState extends State<FoodMenuPage> {
  int totalItems = 0;
  double totalPrice = 0;

  List<FoodItem> foodItems = [
    FoodItem(
      name: 'Breakfast Buffets',
      rating: 3.9,
      reviews: 200,
      cuisine: 'Asian, Middle Eastern, Western Cuisine',
      discount: 25,
      price: 499.0,
      imagePath: 'assets/images/breakfast_buffet.jpg',
      description: 'Savor the best of Asian, Middle Eastern, and Western breakfast delights at our expansive buffet! Begin your day with a vibrant array of options—enjoy savory dim sum and congee from Asia, indulge in fresh hummus, falafel, and za\'atar flatbreads from the Middle East, or dive into classic Western favorites like scrambled eggs, crispy bacon, and pancakes.',
    ),
    FoodItem(
      name: 'Dinner Buffet',
      rating: 4.2,
      reviews: 300,
      cuisine: 'Asian, Middle Eastern, Western & BBQ',
      discount: 20,
      price: 699.0,
      imagePath: 'assets/images/dinner_buffet.jpg',
      description: 'Treat yourself to an unforgettable dining experience with our exquisite dinner buffet, featuring a delightful mix of Asian, Middle Eastern, and Western cuisines. Explore an impressive variety of fresh, flavorful dishes—enjoy savory Asian stir-fries and sushi, indulge in aromatic Middle Eastern grills and mezze, or savor hearty Western classics like roasted meats, pastas, and seasonal sides.',
    ),
    FoodItem(
      name: 'Set Menu 1',
      rating: 4.0,
      reviews: 250,
      cuisine: 'Salad, Grilled Chicken, Brownie',
      discount: 15,
      price: 299.0,
      imagePath: 'assets/images/setmenu1.jpg',
      description: 'A healthy, satisfying meal with fresh salad, juicy grilled chicken, and a rich brownie to satisfy your sweet tooth. Enjoy a perfect blend of nutrition and taste.',
    ),
    FoodItem(
      name: 'Set Menu 2',
      rating: 4.3,
      reviews: 350,
      cuisine: 'Garlic Bread, Pasta, Tiramisu, Italian drinks',
      discount: 10,
      price: 399.0,
      imagePath: 'assets/images/setmenu2.jpg',
      description: 'Indulge in a classic Italian feast with delicious garlic bread, savory pasta, rich tiramisu, and refreshing Italian drinks. A perfect meal for Italian cuisine lovers!',
    ),
  ];

  void addItem(double price) {
    setState(() {
      totalItems++;
      totalPrice += price;
    });
  }

  void continueToPayment() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Payment Summary'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Total Items: $totalItems'),
            Text('Total Price: ฿$totalPrice'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food Menu'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: foodItems.length,
              itemBuilder: (context, index) {
                var item = foodItems[index];
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                      child: ListTile(
                        contentPadding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 0.0),
                        leading: Image.asset(
                          item.imagePath,
                          width: 60,
                          height: 60,
                          fit: BoxFit.cover,
                        ),
                        title: Text(item.name),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item.cuisine),
                            Text('⭐ ${item.rating} (${item.reviews} Reviews)'),
                          ],
                        ),
                        trailing: FittedBox(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('฿${item.price}'),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Color(0xFFA86B32),
                                  foregroundColor: Colors.white,
                                ),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => FoodDetailPage(
                                        foodItem: item,
                                        onAddToCart: (price) {
                                          addItem(price);
                                        },
                                      ),
                                    ),
                                  );
                                },
                                child: Text('Add'),
                              ),
                            ],
                          ),
                        ),
                        onTap: () {},
                      ),
                    ),
                    Divider(
                      color: Color(0xFFA86B32),
                      thickness: 2,
                      indent: 16,
                      endIndent: 16,
                    ),
                  ],
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Total items added: $totalItems'),
                    Text('Total price: ฿$totalPrice'),
                  ],
                ),
                SizedBox(height: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFA86B32),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ReservationCompletionPage(),
                      ),
                    );
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Reservation Confirmed! 🎉")),
                    );
                  },
                  child: Text('Confirm Your Reservation'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class FoodItem {
  final String name;
  final double rating;
  final int reviews;
  final String cuisine;
  final int discount;
  final double price;
  final String imagePath;
  final String description;

  FoodItem({
    required this.name,
    required this.rating,
    required this.reviews,
    required this.cuisine,
    required this.discount,
    required this.price,
    required this.imagePath,
    required this.description,
  });
}

class FoodDetailPage extends StatelessWidget {
  final FoodItem foodItem;
  final Function(double price) onAddToCart;

  FoodDetailPage({required this.foodItem, required this.onAddToCart});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(foodItem.name),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              foodItem.name,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16), // Fixed issue here
            Image.asset(foodItem.imagePath), // Image properly placed
            const SizedBox(height: 16), // Proper spacing
            Text(
              foodItem.description,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            Center(
              child: SizedBox(
                width: 250,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFA86B32),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () {
                    // Add the item to the cart
                    onAddToCart(foodItem.price); // Notify the parent screen
                    Navigator.pop(context);
                  },
                  child: const Text('Add to Cart'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}