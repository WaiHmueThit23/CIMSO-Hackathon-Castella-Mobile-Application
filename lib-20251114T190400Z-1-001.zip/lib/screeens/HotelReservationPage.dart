import 'package:flutter/material.dart';
import 'HotelDetailPage.dart';
import 'HotelReservationPageHistory.dart';
import 'ProfilePage.dart';
import 'SearchPage.dart';
import 'TypeReservationPage.dart';


class HotelReservationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Hotels"),
        centerTitle: true,
        backgroundColor: Color(0xFFA86B32),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // Deluxe Room Card
          HotelCard(
            name: "Deluxe Room",
            location: "3 more locations found",
            price: "฿ 1399/night",
            imageUrl: "assets/images/deluxeroom.jpg",
            isSuiteRoom: false,
          ),
          SizedBox(height: 10),
          // Suite Room Card
          HotelCard(
            name: "Suite Room",
            location: "2 more locations found",
            price: "฿ 1599/night",
            imageUrl: "assets/images/suiteroom.jpg",
            isSuiteRoom: true,
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 0),
    );
  }
}

class HotelCard extends StatelessWidget {
  final String name;
  final String location;
  final String price;
  final String imageUrl;
  final bool isSuiteRoom;

  HotelCard({required this.name, required this.location, required this.price, required this.imageUrl, required this.isSuiteRoom});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image Slider (Horizontal Scrollable)
          Container(
            height: 150,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                Image.asset(imageUrl, width: 330, fit: BoxFit.cover),
                // Add more images if needed
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Hotel Name
                Text(name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                // Location
                Text(location, style: TextStyle(color: Colors.grey)),
                SizedBox(height: 4),
                // Price
                Text(price, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                // View Details Button
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => isSuiteRoom ? SuiteRoomPage() : HotelDetailPage(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Color(0xFFA86B32)),
                  child: Text("View Details"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;

  const CustomBottomNavBar({Key? key, required this.currentIndex}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      selectedItemColor: Color(0xFFA86B32),
      unselectedItemColor: Colors.grey,
      onTap: (index) {
        if (index == currentIndex) return;

        Widget page;
        switch (index) {
          case 0:
            page = TypeReservationPage();
            break;
          case 1:
            page = SearchPage();
            break;
          case 2:
            page = HotelReservationPageHistory(userData: {},);
            break;
          case 3:
            page = ProfilePage(userData: {});
            break;
          default:
            return;
        }

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
        BottomNavigationBarItem(icon: Icon(Icons.book), label: "Booking"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ],
    );
  }
}
