class UserData {
  String fullName;
  String nickName;
  String dob;
  String email;
  String phone;
  String gender;

  UserData({
    required this.fullName,
    required this.nickName,
    required this.dob,
    required this.email,
    required this.phone,
    required this.gender,
  });
}
